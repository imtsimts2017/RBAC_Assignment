﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using RBAC.Models;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace RBAC.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AccountController : ControllerBase
    {
        private readonly UserManager<IdentityUser> _userManager;
        private readonly RoleManager<IdentityRole> _roleManager;
        private readonly SignInManager<IdentityUser> _signInManager;
        private readonly IConfiguration _configuration;

        public AccountController(UserManager<IdentityUser> userManager, RoleManager<IdentityRole> roleManager, IConfiguration configuration)
        {
            _userManager = userManager;
            _roleManager = roleManager;
            _configuration = configuration;
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] Register model)
        {
            try
            {
                if (model.Username=="" || model.Username == null)
                {
                    return Ok(new { message = "Please provide username" });
                }
                var user = new IdentityUser { UserName = model.Username, Email = model.Email };
                if (user != null)
                {
                    var existUser = await _userManager.FindByNameAsync(model.Username);
                    if (existUser != null)
                    {
                        return Ok(new { message = "User already registered" });
                    }
                    var result = await _userManager.CreateAsync(user, model.Password);

                    if (result.Succeeded)
                    {
                        if (!await _roleManager.RoleExistsAsync(model.RoleName))
                        {
                            var roleCreated = await _roleManager.CreateAsync(new IdentityRole(model.RoleName));
                            var roleResult = await _userManager.AddToRoleAsync(user, model.RoleName);
                            if (roleResult.Succeeded)
                            {
                                return Ok(new { message = "User created successfully" });
                            }
                            else
                            {
                                return BadRequest(result.Errors);
                            }
                        }
                        return Ok(new { message = "User registered successfully" });
                    }
                    else
                    {
                        return BadRequest(result.Errors);
                    }
                }
                return BadRequest("Please provide username");
            }
            catch (Exception ex)
            {

                return BadRequest(ex.Message);
            }
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] Login model)
        {
            try
            {
                var user = await _userManager.FindByNameAsync(model.Username);
                if (user != null && await _userManager.CheckPasswordAsync(user, model.Password))
                {
                    var userRoles = await _userManager.GetRolesAsync(user);
                    var authClaims = new List<Claim>
                {
                    new Claim(JwtRegisteredClaimNames.Sub, user.UserName),
                    new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
                };

                    authClaims.AddRange(userRoles.Select(role => new Claim(ClaimTypes.Role, role)));

                    var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]!));
                    var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

                    var token = new JwtSecurityToken(_configuration["Jwt:Issuer"],
            _configuration["Jwt:Issuer"],
            authClaims,
            expires: DateTime.Now.AddMinutes(120),
            signingCredentials: credentials);

                    return Ok(new { Token = new JwtSecurityTokenHandler().WriteToken(token), role = userRoles[0] });
                }
                return Unauthorized();
            }
            catch (Exception ex)
            {

                return BadRequest(ex.Message);
            }
        }

        [HttpPost("add-role")]
        public async Task<IActionResult> AddRole([FromBody] string role)
        {
            try
            {
                if (!await _roleManager.RoleExistsAsync(role))
                {
                    var result = await _roleManager.CreateAsync(new IdentityRole(role));
                    if (result.Succeeded)
                    {
                        return Ok(new { message = "Role added successfully" });
                    }
                    else
                    {
                        return BadRequest(result.Errors);
                    }
                }
                return BadRequest("Role already exist");
            }
            catch (Exception ex)
            {

                return BadRequest(ex.Message);
            }
        }

        [HttpPost("assign-role")]
        public async Task<IActionResult> AssignRole([FromBody] UserRole model)
        {
            try
            {
                var user = await _userManager.FindByNameAsync(model.Username);
                if (user == null)
                {
                    return BadRequest("User not found");
                }
                var result = await _userManager.AddToRoleAsync(user, model.Role);
                if (result.Succeeded)
                {
                    return Ok(new { message = "Role assigned successfully" });
                }
                return BadRequest(result.Errors);
            }
            catch (Exception ex)
            {

                return BadRequest(ex.Message);
            }
        }

        [HttpGet("getAllUsers")]
        public async Task<IActionResult> ListUsers()
        {
            try
            {
                var users = _userManager.Users.ToList();
                return Ok(users);
            }
            catch (Exception ex)
            {

                return BadRequest(ex.Message);
            }
        }

        [HttpGet("getAllRoles")]
        public async Task<IActionResult> ListRoles()
        {
            try
            {
                var roles = _roleManager.Roles.ToList();
                return Ok(roles);
            }
            catch (Exception ex)
            {

                return BadRequest(ex.Message);
            }
        }

        [HttpPost("userRoleUpdate")]
        public async Task<IActionResult> UserRoleUpdate([FromBody] UpdateUserRole model)
        {
            // THIS LINE IS IMPORTANT
            var userDetails = await _userManager.FindByNameAsync(model.Username);
            var roles = await _userManager.GetRolesAsync(userDetails);
            //Then remove all the assigned roles for this user
            var result = await _userManager.RemoveFromRolesAsync(userDetails, roles);
            var roleAssigned = await _userManager.AddToRoleAsync(userDetails, model.RoleName);
            if (roleAssigned.Succeeded)
            {
                return Ok(new { message = "Role updated successfully" });
            }
            else
            {
                return BadRequest();
            }
        }

        public class UpdateUserRole
        {
            public string Username { get; set; } = string.Empty;
            public string RoleName { get; set; } = string.Empty;
        }

    }
}
