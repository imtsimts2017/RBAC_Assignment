﻿

using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RBAC.Data;
using RBAC.Models;

namespace RBAC.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerController : ControllerBase
    {
        private readonly AppDbContext _dbContext;
        public CustomerController(AppDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        [HttpGet("GetCustomers")]
        public async Task<ActionResult<IEnumerable<Customer>>> GetCustomers()
        {
            try
            {
                if (_dbContext.Customers == null)
                {
                    return NotFound();
                }
                return await _dbContext.Customers.ToListAsync();
            }
            catch (Exception ex)
            {

                return BadRequest(ex.Message);
            }
        }

        [HttpGet("GetCustomer/{id}")]
        public async Task<ActionResult<Customer>> GetCustomer(int id)
        {
            try
            {
                if (_dbContext.Customers == null)
                {
                    return NotFound();
                }
                var customer = await _dbContext.Customers.Where(x => x.Id == id).FirstOrDefaultAsync();
                if (customer == null)
                {
                    return NoContent();
                }
                return customer;
            }
            catch (Exception ex)
            {

                return BadRequest(ex.Message);
            }
        }

        [HttpPost("PostCustomers")]
        public async Task<ActionResult<Customer>> PostCustomers(Customer model)
        {
            try
            {
                _dbContext.Customers.Add(model);
                await _dbContext.SaveChangesAsync();

                return CreatedAtAction(nameof(GetCustomer), new { id = model.Id }, model);
            }
            catch (Exception ex)
            {

                return BadRequest(ex.Message);
            }
        }

        [HttpPut("PutCustomer/{id}")]
        public async Task<IActionResult> PutCustomer(int id, Customer model)
        {
            try
            {
                if (id != model.Id)
                {
                    return BadRequest();
                }
                _dbContext.Entry(model).State = EntityState.Modified;

                try
                {
                    await _dbContext.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CustomerAvailable(id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return Ok();
            }
            catch (Exception ex)
            {

                return BadRequest(ex.Message);
            }
        }

        private bool CustomerAvailable(int id)
        {
            return (_dbContext.Customers?.Any(x=>x.Id == id)).GetValueOrDefault();
        }

        [HttpDelete("DeleteCustomer/{id}")]
        public async Task<IActionResult> DeleteCustomer(int id)
        {
            try
            {
                if (_dbContext.Customers == null)
                {
                    return NotFound();
                }
                var customer = await _dbContext.Customers.Where(x => x.Id == id).FirstOrDefaultAsync();
                if (customer == null)
                {
                    return NotFound();
                }
                _dbContext.Customers.Remove(customer);

                await _dbContext.SaveChangesAsync();
                return Ok();
            }
            catch (Exception ex)
            {

                return BadRequest(ex.Message);
            }
        }
    }
}
