import logo from "./logo.svg";
import "./App.css";
import Login from "./login/Login";
import Signup from "./signup/Signup";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import Dashboard from "./Components/Dashboard";
import Home from "./Components/Home";
import Create from "./Components/Create";
import Update from "./Components/Update";
import Read from "./Components/Read";
import bootstrap from "bootstrap/dist/css/bootstrap.min.css";
import NotAuthorized from "./Components/NotAuthorized";
import ChangeUserRole from "./Components/ChangeUserRole";

function App() {
  const currentUser = {
    role: localStorage.getItem("role"), // Change to 'admin' or 'user' to test
  };

  // Role-based route guard
  const ProtectedRoute = ({ role, allowedRoles, children }) => {
    if (!allowedRoles.includes(role)) {
      return <Navigate to="/not-authorized" replace />;
    }
    return children;
  };

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Login />}></Route>
        <Route path="/login" element={<Login />}></Route>
        <Route path="/signup" element={<Signup />}></Route>

        <Route
          path="/home"
          element={
            <ProtectedRoute
              role={currentUser.role}
              allowedRoles={["Admin", "Editor", "Viewer"]}
            >
              <Home />
            </ProtectedRoute>
          }
        />

        <Route
          path="/create"
          element={
            <ProtectedRoute
              role={currentUser.role}
              allowedRoles={["Admin", "Editor"]}
            >
              <Create />
            </ProtectedRoute>
          }
        />

        <Route
          path="/update/:id"
          element={
            <ProtectedRoute
              role={currentUser.role}
              allowedRoles={["Admin", "Editor"]}
            >
              <Update />
            </ProtectedRoute>
          }
        />

        <Route
          path="/read/:id"
          element={
            <ProtectedRoute
              role={currentUser.role}
              allowedRoles={["Admin", "Editor", "Viewer"]}
            >
              <Read />
            </ProtectedRoute>
          }
        />

        <Route
          path="/changeUserRole"
          element={
            <ProtectedRoute role={currentUser.role} allowedRoles={["Admin"]}>
              <ChangeUserRole />
            </ProtectedRoute>
          }
        />

        {/* <Route path="/home" element={<Home />}></Route> */}
        {/* <Route path="/create" element={<Create />}></Route> */}
        {/* <Route path="/update/:id" element={<Update />}></Route> */}
        {/* <Route path="/read/:id" element={<Read />}></Route> */}
        <Route path="/not-authorized" element={<NotAuthorized />} />
        <Route path="/changeUserRole" element={<ChangeUserRole />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
