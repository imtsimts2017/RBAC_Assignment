import React from 'react'
import axios from 'axios';
import  { useEffect, useState } from 'react'
import { Link } from "react-router-dom";

function ChangeUserRole() {
    const [usersData, setUsersData] = useState([]);
    const [rolesData, setRolesData] = useState([]);

    const [data, setData] = useState({
        username: "",
        roleName: "",
      });
      const { username, roleName } = data;

    useEffect(()=>{
        axios.get('http://localhost:5019/api/Account/getAllUsers')
        .then(res=>{
            setUsersData(res.data);
            console.log(res.data);
        })
        .catch(err=>console.log(err));

        axios.get('http://localhost:5019/api/Account/getAllRoles')
        .then(res=>{
            setRolesData(res.data);
            console.log(res.data);
        })
        .catch(err=>console.log(err));
    },[]);

    const ChangeHandler = (e) => {
    setData({ ...data, [e.target.name]: e.target.value });
  };

    const handleSubmit = (event) => {
        event.preventDefault();
        // axios.post('http://localhost:5019/api/Account/userRoleUpdate',data)
        // .then(res => {
        //     console.log(res);
        // })
        // .catch(err => console.log(err));

        axios({
      method: "POST",
      url: "http://localhost:5019/api/Account/userRoleUpdate",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      data: JSON.stringify(data),
    })
      .then((res) => {
        console.log("result : ", res.data.message);
        alert(res.data.message);        
      })
      .catch((err) => {
        console.log("error in request : ", err);
      });
    }

  return (
    <div className='d-flex w-100 vh-100 justify-content-center align-items-center bg-ligt'>
      <div className='w-50 border bg-white shadow px-5 pt-3 pb-5 rounded'>
        <h1>Change User Role</h1>
        <form onSubmit={handleSubmit}>
            <div className='mb-2'>
                <label htmlFor="users">Users:</label>
                 <select name="username"
                value={username}
                onChange={ChangeHandler} className="form-control">
                    <option value="Select">--Select--</option>
                    {usersData.map(item => (
                        <option
                        key={item.id}
                        value={item.userName}
                        >
                        {item.userName}
                        </option>
                    ))}
                    </select>
                
            </div>
            <div className='mb-2'>
                <label htmlFor="roles">Roles:</label>
                 <select name="roleName"
                value={roleName}
                onChange={ChangeHandler} className="form-control">
                    <option value="Select">--Select--</option>
                    {rolesData.map(item => (
                        <option
                        key={item.id}
                        value={item.name}
                        >
                        {item.name}
                        </option>
                    ))}
                    </select>
                
            </div>
            <button className='btn btn-success'>Submit</button>
            <Link to="/home" className='btn btn-primary ms-3'>Back</Link>
        </form>
      </div>
    </div>
  )
}

export default ChangeUserRole
