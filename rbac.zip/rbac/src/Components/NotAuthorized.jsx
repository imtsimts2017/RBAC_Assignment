import { Link } from 'react-router-dom'

const NotAuthorized = () => {

    return(
        <div>
            <h1>403 - Not Authorized</h1>;
            <br />
            <Link to="/home" className='btn btn-primary ms-3'>Back</Link>
        </div>
    )
   
}


export default NotAuthorized;
