
import React from 'react'
import { useEffect, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useParams } from 'react-router-dom';
import axios from 'axios'

function Update() {
    //const [data, setData] = useState([]);
    
    const {id} = useParams();

    const [values, setValues]=useState({
        email : '',
        name : '',
        phoneNo : ''
    });

        useEffect(()=>{
            axios.get('http://localhost:5019/api/Customer/GetCustomer/'+id)
            .then(res=>{
                setValues(res.data);
            })
            .catch(err=>console.log(err));
        },[]);

        const navigate = useNavigate();

        const handleUpdate =(event)=>{
            event.preventDefault();
            axios.put('http://localhost:5019/api/Customer/PutCustomer/'+id,values)
            .then(res => {
                console.log(res);
                navigate('/home');
            })
            .catch(err => console.log(err));
    }

        
  return (
    <div className='d-flex w-100 vh-100 justify-content-center align-items-center bg-ligt'>
      <div className='w-50 border bg-white shadow px-5 pt-3 pb-5 rounded'>
        <h1>Update Customer</h1>
        <form onSubmit={handleUpdate}>
            <div className='mb-2'>
                <label htmlFor="name">Name:</label>
                <input type='text' id="name"  name='name' className='form-control' placeholder='Enter Name'
                value={values.name} onChange={(e)=>setValues({...values, name: e.target.value})} />
            </div>
            <div className='mb-2'>
                <label htmlFor="email">Email:</label>
                <input type='email' name='email' className='form-control' placeholder='Enter Name'
                value={values.email} onChange={(e)=>setValues({...values, email: e.target.value})} />
            </div>
            <div className='mb-2'>
                <label htmlFor="phoneno">Phone No:</label>
                <input type='text' name='phoneno' className='form-control' placeholder='Enter Name'
                value={values.phoneNo} onChange={(e)=>setValues({...values, phoneNo: e.target.value})} />
            </div>
            <button className='btn btn-success'>Submit</button>
            <Link to="/home" className='btn btn-primary ms-3'>Back</Link>
        </form>
      </div>
    </div>
  )
}

export default Update
