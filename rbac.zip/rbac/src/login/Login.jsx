
import React from 'react'
import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import axios from "axios";

const Login = () => {
    const [data, setData] = useState({
        username: "",
        password: ""
      });
      const { username, password } = data;
    
      const ChangeHandler = (e) => {
        setData({ ...data, [e.target.name]: e.target.value });
      };

      const LoginHandler = (e) => {
    e.preventDefault();
    if(username == null || username == "")
    {
      alert("Please enter username");
      return false;
    }
    if(password == null || password == "")
    {
      alert("Please enter password");
      return false;
    }

    axios({
      method: "POST",
      url: "http://localhost:5019/api/Account/login",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      data: data,
    })
      .then((res) => {
        
        console.log(res.data.token);
        console.log(res.data.role);
        localStorage.setItem('token',res.data.token);
        localStorage.setItem('role',res.data.role);
        window.location.href = "/home";
      })
      .catch((err) => {
        console.log("error in request : ", err);
      });
  };
  return (
    <div className='login template d-flex justify-content-center align-items-center 100-w vh-100 bg-primary'>
      <div className='form-container p-5 rounded bg-white'>
        <form>
          <h3 className='text-center'>Login</h3>
          <div className='mb-2'>
            <label htmlFor='email'>Username</label>
            <input type='text' placeholder='username' className='form-control' name="username"
            value={username} onChange={ChangeHandler} />
          </div>
          <div className='mb-2'>
            <label htmlFor='password'>Pasword</label>
            <input type='password' placeholder='Enter Password' className='form-control' name="password"
            value={password} onChange={ChangeHandler} />
          </div>
          <div className='mb-2'>
            <input type='checkbox' className='custom-control custom-checkbox' id="check" />
            <label htmlFor='check' className='custom-input-label ms-2'>Remember me</label>
          </div>
          <div className='d-grid'>
            <button className='btn btn-primary' onClick={LoginHandler}>Login</button>
          </div>
          <p className='text-end mt-2'>
            <a href='' className=''>Forgot Password?</a><Link to="/signup" className='ms-2'>Sign up</Link>
          </p>
        </form>
      </div>
        {/* <form>
            <u><h4>Login</h4></u>
            <input
            type="text"
            placeholder="username"
            name="username"
            value={username}
            onChange={ChangeHandler}
          />
          <br />
          <input
            type="password"
            placeholder="password"
            name="password"
            value={password}
            onChange={ChangeHandler}
          />
          <br />
            <button type='submit' className="btn btn-primary" onClick={LoginHandler}>
            Login
            </button>
        </form>
      <Link to="/" type='submit' className="btn btn-primary">
      Signup
      </Link> */}
    </div>
  )
}

export default Login
