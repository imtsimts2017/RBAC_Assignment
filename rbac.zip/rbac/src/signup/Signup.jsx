
import React from 'react'
import { Link } from "react-router-dom";
import { useEffect, useState } from "react";
import axios from "axios";

const Signup = () => {
    const [data, setData] = useState({
    username: "",
    email: "",
    password: "",
    roleName: "",
  });
  const { username, email, password, roleName } = data;

  const ChangeHandler = (e) => {
    setData({ ...data, [e.target.name]: e.target.value });
  };

  // async function SignupHandleryyy(params) {
  //   let result = fetch("http://localhost:5019/api/Account/register", {
  //     method: "POST",
  //     headers: {
  //       "Content-Type": "application/json",
  //       Accept: "application/json",
  //     },
  //     body: JSON.stringify(data),
  //   });
  //   result = (await result).json();
  //   console.log(result);
  // }

  const SignupHandler = (e) => {
    e.preventDefault();

    if(username == null || username == "")
    {
      alert("Please enter username");
      return false;
    }
    if(email == null || email == "")
    {
      alert("Please enter email");
      return false;
    }
    if(password == null || password == "")
    {
      alert("Please enter password");
      return false;
    }
    if(roleName == null || roleName == "")
    {
      alert("Please select role");
      return false;
    }

    console.log(data);
    axios({
      method: "POST",
      url: "http://localhost:5019/api/Account/register",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      data: data,
    })
      .then((res) => {
        console.log("result : ", res.data.message);
        alert(res.data.message);
        username("");
        email("");
        password("");
      })
      .catch((err) => {
        console.log("error in request : ", err);
      });
  };

  function roleHandler(event) {
    roleName(event.target.name);
  }

  const LoginHandler = (e) => {
    e.preventDefault();
    console.log(data);
  };

  return (
    <div className='signup template d-flex justify-content-center align-items-center 100-w vh-100 bg-primary'>
        <div className='form-container p-5 rounded bg-white'>
            <form>
              <h3 className='text-center'>Sign up</h3>
              <div className='mb-2'>
                <label htmlFor='username'>Email</label>
                <input type='text' placeholder=' Enter username' className='form-control' name="username"
                value={username} onChange={ChangeHandler} />
              </div>
              <div className='mb-2'>
                <label htmlFor='email'>Email</label>
                <input type='email' placeholder='Enter email' className='form-control' name="email"
                value={email} onChange={ChangeHandler} />
              </div>
              <div className='mb-2'>
                <label htmlFor='password'>Pasword</label>
                <input type='password' placeholder='Enter Password' className='form-control' name="password"
                value={password} onChange={ChangeHandler} />
              </div>
              <div className='mb-2'>
                <label htmlFor='roles'>Roles</label>
                <select
                name="roleName"
                value={roleName}
                onChange={ChangeHandler}
                className="form-control"
              >
                <option value="Select">--Select--</option>
                <option value="Admin">Admin</option>
                <option value="Editor">Editor</option>
                <option value="Viewer">Viewer</option>
              </select>
              </div>
              <div className='d-grid'>
                <button className='btn btn-primary' onClick={SignupHandler}>Sign up</button>
              </div>
              <p className='text-end mt-2'>
                Already registered?<Link to="/login" className='ms-2'>Login</Link>
              </p>
            </form>
          </div>
          </div>
    
    // <div>
    //     <form>
    //         <div>
    //             <u><h4>Signup</h4></u>
    //             <input
    //         type="text"
    //         placeholder="username"
    //         name="username"
    //         value={username}
    //         onChange={ChangeHandler}
    //       />
    //       <br />
    //       <input
    //         type="email"
    //         placeholder="email"
    //         name="email"
    //         value={email}
    //         onChange={ChangeHandler}
    //       />
    //       <br />
    //       <input
    //         type="password"
    //         placeholder="password"
    //         name="password"
    //         value={password}
    //         onChange={ChangeHandler}
    //       />
    //       <br />
    //       <select
    //         name="roleName"
    //         value={roleName}
    //         onChange={ChangeHandler}
    //         className="form-control"
    //       >
    //         <option value="Select">--Select--</option>
    //         <option value="Admin">Admin</option>
    //         <option value="Editor">Editor</option>
    //         <option value="Viewer">Viewer</option>
    //       </select>
    //       <br />
    //         </div>

    //         <button type='submit' class="btn btn-primary" onClick={SignupHandler}>
    //         Signup
    //         </button>
    //     </form>
    //   <Link to="/login" type='submit' class="btn btn-primary">
    //   Login
    //   </Link>
    // </div>
  )
}

export default Signup
